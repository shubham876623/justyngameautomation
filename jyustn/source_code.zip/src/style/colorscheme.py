bg_color = '#212024'

bg_log = '#2C2D30'

second_color = '#2C2D30'

complement_color = 'rgba(199, 207, 214, 18%)'

text_color = '#FFFFFF'

purple_color = '#CA50D9'

transparent = 'rgba(0, 0, 0, 0)'

seledyn_color = '#32E6B7'

red_color = '#D9506B'

green_color = '#82D930'

log_aux_color = 'rgba(199, 207, 214, 8%)'

log_aux_color_clicked = 'rgba(199, 207, 214, 12%)'